
sap.ui.define([
  'jquery.sap.global',
  "sap/dm/dme/podfoundation/controller/PluginViewController",
  "sap/ui/model/json/JSONModel",
  "sap/dm/dme/podfoundation/util/PodUtility",
  "sap/dm/dme/util/PlantSettings",
  "sap/m/MessageToast"
], function (jQuery, PluginViewController, JSONModel, PodUtility, PlantSettings, MessageToast) {
  "use strict";

  // --- helpers ---------------------------------------------------------------

  function isFunction(fn) {
    return typeof fn === "function";
  }

  // Only names that start with "get"
  function startsWithGet(name) {
    return /^get/.test(name);
  }

  // Safe stringifier with circular guard
  function stringifySafe(value) {
    try {
      if (value === undefined) return "undefined";
      if (value === null) return "null";
      if (typeof value === "string") return value;
      if (typeof value === "number" || typeof value === "boolean") return String(value);
      if (value instanceof Date) return value.toISOString();

      const seen = new WeakSet();
      return JSON.stringify(value, function (key, val) {
        if (typeof val === "object" && val !== null) {
          if (seen.has(val)) return "[Circular]";
          seen.add(val);
        }
        return val;
      });
    } catch (e) {
      return "[Unserializable: " + e.message + "]";
    }
  }

  // Walk the FULL prototype chain and collect get* method names
  function collectGetMethodNamesFullChain(obj) {
    const names = new Set();
    let curr = obj;

    while (curr && curr !== Object.prototype) {
      let props = [];
      try {
        props = Object.getOwnPropertyNames(curr);
      } catch (e) {
        props = [];
      }

      for (const n of props) {
        if (!startsWithGet(n)) continue;
        if (names.has(n)) continue;

        const desc = Object.getOwnPropertyDescriptor(curr, n);
        // Only collect real function values; ignore accessors (getters/setters)
        if (desc && typeof desc.value === "function") {
          names.add(n);
        }
      }

      try {
        curr = Object.getPrototypeOf(curr);
      } catch (e) {
        break;
      }
    }

    return Array.from(names).sort();
  }

  // CSV helpers
  function csvEscape(field) {
    const s = field == null ? "" : String(field);
    // Escape double quotes by doubling them; wrap every field in quotes
    return `"${s.replace(/"/g, '""')}"`;
  }

  function buildCsv(rows, targetLabel) {
    const headers = ["Target", "Name", "Full Path", "Type/Arity", "Sync/Async", "Value"];
    const lines = [];
    lines.push(headers.map(csvEscape).join(","));

    rows.forEach(r => {
      lines.push([
        csvEscape(targetLabel),
        csvEscape(r.name || ""),
        csvEscape(r.fullPath || ""),
        csvEscape(r.arity || ""),
        csvEscape(r.async || ""),
        csvEscape(r.value || "")
      ].join(","));
    });

    return lines.join("\n");
  }

  function downloadCsv(content, filename) {
    try {
      const blob = new Blob([content], { type: "text/csv;charset=utf-8" });

      // IE/Edge Legacy
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob, filename);
        return;
      }

      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      MessageToast.show("CSV exported");
    } catch (e) {
      MessageToast.show("CSV export failed");
    }
  }

  // --- controller ------------------------------------------------------------

  return PluginViewController.extend("br.custom.plugins.getessentialmethods.controller.MainView", {
    onInit: function () {
      PluginViewController.prototype.onInit.apply(this, arguments);

      // Inspector model drives the table + state
      this._inspectorModel = new JSONModel({
        methods: [],              // table rows (get* methods + optional attributes)
        filter: "",
        target: "podController",  // default target shown in Select
        showAttributes: false     // default OFF per your request
      });
      this.getView().setModel(this._inspectorModel, "inspector");
    },

    onAfterRendering: function(){
      // Existing config-based UI setup
      this.getView().byId("backButton").setVisible(this.getConfiguration().backButtonVisible);
      this.getView().byId("closeButton").setVisible(this.getConfiguration().closeButtonVisible);
      this.getView().byId("headerTitle").setText(this.getConfiguration().title);
      this.getView().byId("textPlugin").setText(this.getConfiguration().text);

      // Sync target select initial key
      var sel = this.getView().byId("targetSelect");
      if (sel) {
        sel.setSelectedKey(this._inspectorModel.getProperty("/target"));
      }
    },

    // ===== Target handling =====
    onTargetChanged: function (oEvent) {
      var key = oEvent.getSource().getSelectedKey();
      this._inspectorModel.setProperty("/target", key);
      // Refresh the list for the new target
      this.onListFilteredMethods();
    },

    // Toggle attributes on/off
    onToggleShowAttributes: function (oEvent) {
      var state = oEvent.getParameter("state");
      this._inspectorModel.setProperty("/showAttributes", !!state);
      // Rebuild the list with attributes included/excluded
      this.onListFilteredMethods();
    },

    _getTargetObject: function () {
      var target = this._inspectorModel.getProperty("/target");

      if (target === "this") {
        // Inspect the controller instance itself
        return this;
      }

      if (target === "podController") {
        return this.getPodController();
      }

      if (target === "podSelectionModel") {
        var pc = this.getPodController();
        return pc && typeof pc.getPodSelectionModel === "function" ? pc.getPodSelectionModel() : null;
      }

      if (target === "plantSetting") {
        // Use PlantSettings directly (imported above)
        if (!PlantSettings) return null;
        if (typeof PlantSettings.getInstance === "function") {
          try {
            return PlantSettings.getInstance();
          } catch (e) {
            return PlantSettings;
          }
        }
        return PlantSettings;
      }

      if (target === "podUtility") {
        // Pod Utility target
        return PodUtility || null;
      }

      return null;
    },

    // Human-friendly label and prefix
    _getTargetLabel: function () {
      const target = this._inspectorModel.getProperty("/target");
      switch (target) {
        case "this":            return "This Controller";
        case "podController":   return "POD Controller";
        case "podSelectionModel": return "POD Selection Model";
        case "plantSetting":    return "Plant Setting";
        case "podUtility":      return "Pod Utility";
        default:                return "Unknown";
      }
    },

    _getTargetPrefix: function () {
      const target = this._inspectorModel.getProperty("/target");
      switch (target) {
        case "this":
          return "this";
        case "podController":
          return "this.getPodController()";
        case "podSelectionModel":
          return "this.getPodController().getPodSelectionModel()";
        case "plantSetting":
          return "PlantSettings";
        case "podUtility":
          return "PodUtility";
        default:
          return "(unknownTarget)";
      }
    },

    // ===== List only get* methods (full prototype chain) + (optional) attributes =====
    onListFilteredMethods: function () {
      const obj = this._getTargetObject();
      if (!obj) {
        this._setMethods([{
          name: "[target not available]",
          arity: "-",
          async: "-",
          fullPath: "",
          value: "Selected target resolved to null/undefined"
        }]);
        this.__allMethods = null;
        return;
      }

      const showAttrs = !!this._inspectorModel.getProperty("/showAttributes");
      const prefix = this._getTargetPrefix();

      // METHODS: collect from full prototype chain
      const methodNames = collectGetMethodNamesFullChain(obj);

      // Build rows for methods with accurate arity + full path
      const methodRows = methodNames.map(n => {
        let arity = 0;
        try {
          let curr = obj;
          while (curr && curr !== Object.prototype) {
            const desc = Object.getOwnPropertyDescriptor(curr, n);
            if (desc && typeof desc.value === "function") {
              arity = desc.value.length || 0;
              break;
            }
            curr = Object.getPrototypeOf(curr);
          }
        } catch (e) { /* ignore */ }

        const callSig = arity > 0 ? `${prefix}.${n}(/* ${arity} args */)` : `${prefix}.${n}()`;

        return {
          name: n,
          arity: "args: " + arity,
          async: "(unknown)",
          fullPath: callSig,  // <- copy/paste ready
          value: ""           // filled on call
        };
      });

      // ATTRIBUTES: own non-function props only (optional)
      let attributeRows = [];
      if (showAttrs) {
        try {
          const attributeNames = Object.getOwnPropertyNames(obj)
            .filter(n => typeof obj[n] !== "function")
            .sort();

          attributeRows = attributeNames.map(n => ({
            name: n,
            arity: "attribute",
            async: "-",
            fullPath: `${prefix}.${n}`, // <- copy/paste ready attribute path
            value: stringifySafe(obj[n])
          }));
        } catch (e) { /* ignore */ }
      }

      const rows = methodRows.concat(attributeRows);

      // Diagnostics
      /* eslint-disable no-console */
      console.log("[Inspector] target:", this._inspectorModel.getProperty("/target"),
                  "get* methods (full chain):", methodRows.length,
                  "attributes shown:", attributeRows.length,
                  "total rows:", rows.length);

      // Keep a copy for UI search filtering
      this.__allMethods = rows.slice(0);
      this._setMethods(rows);

      // Clear table selection (if any)
      const table = this.getView().byId("methodsTable");
      if (table && typeof table.removeSelections === "function") {
        table.removeSelections(true);
      }
    },

    // ===== Call all zero-argument get* methods (ONLY get*) =====
    onCallAllZeroArgMethods: async function () {
      const obj = this._getTargetObject();
      if (!obj) { return; }

      const data = this._inspectorModel.getData();
      const rows = data.methods;

      // Only pass get* methods to the invoker
      const getRows = rows.filter(r => /^get/.test(r.name));
      await this._invokeRows(obj, getRows);

      // Update the model (other rows remain unchanged)
      this._setMethods(rows);
    },

    // ===== Call only selected zero-argument get* methods =====
    onCallSelectedZeroArgMethods: async function () {
      const obj = this._getTargetObject();
      if (!obj) { return; }

      const table = this.getView().byId("methodsTable");
      if (!table) { return; }

      const selectedItems = table.getSelectedItems ? table.getSelectedItems() : [];
      if (!selectedItems || selectedItems.length === 0) {
        return;
      }

      const toInvoke = [];
      for (let i = 0; i < selectedItems.length; i++) {
        const item = selectedItems[i];
        const ctx = item.getBindingContext("inspector");
        if (ctx) {
          const row = ctx.getObject();
          if (row) {
            toInvoke.push(row);
          }
        }
      }

      // Only get* methods will be executed due to guard inside _invokeRows
      await this._invokeRows(obj, toInvoke);
      this._setMethods(this._inspectorModel.getProperty("/methods"));
    },

    // ===== Internal: invoke array of rows (only get* methods, zero-arg) =====
    _invokeRows: async function (obj, rows) {
      for (let i = 0; i < rows.length; i++) {
        const r = rows[i];
        const fn = obj[r.name];

        // Only invoke rows that are get* METHODS
        if (!isFunction(fn) || !startsWithGet(r.name)) {
          r.async = r.async || "-"; // attributes stay as-is
          continue;
        }

        try {
          // Only call zero-argument methods to avoid side-effects
          if (fn.length > 0) {
            r.async = "-";
            r.value = "Skipped (expects " + fn.length + " argument(s))";
            continue;
          }

          let result = fn.call(obj);

          // Promise/async detection with timeout guard
          if (result && typeof result.then === "function") {
            r.async = "async (Promise)";
            result = await Promise.race([
              result,
              new Promise((_, reject) => setTimeout(() => reject(new Error("Timed out after 5s")), 5000))
            ]);
          } else {
            r.async = "sync";
          }

          r.value = stringifySafe(result);

        } catch (err) {
          r.value = "[Error] " + (err && err.message ? err.message : String(err));
          r.async = r.async || "-";
        }
      }
    },

    // ===== Copy full path for a single row =====
    onCopyFullPath: function (oEvent) {
      try {
        const ctx = oEvent.getSource().getBindingContext("inspector");
        const path = ctx && ctx.getProperty("fullPath");
        if (!path) return;

        if (navigator && navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(path).then(function () {
            MessageToast.show("Full path copied");
          }).catch(function () {
            MessageToast.show("Could not copy to clipboard");
          });
        } else {
          // Fallback: select text via temporary input
          const el = document.createElement("textarea");
          el.value = path;
          el.style.position = "fixed";
          el.style.opacity = "0";
          document.body.appendChild(el);
          el.focus(); el.select();
          try { document.execCommand("copy"); MessageToast.show("Full path copied"); }
          catch (e) { MessageToast.show("Could not copy to clipboard"); }
          document.body.removeChild(el);
        }
      } catch (e) {
        MessageToast.show("Copy failed");
      }
    },

    // ===== Export CSV (All) =====
    onExportCsvAll: function () {
      const targetLabel = this._getTargetLabel();
      const rows = (this._inspectorModel.getData().methods || []);
      const csv = buildCsv(rows, targetLabel);
      const ts = new Date().toISOString().replace(/[:.]/g, "-");
      const filename = `methods_${targetLabel.replace(/\s+/g, "_")}_${ts}.csv`;
      downloadCsv(csv, filename);
    },

    // ===== Export CSV (Selected) =====
    onExportCsvSelected: function () {
      const table = this.getView().byId("methodsTable");
      if (!table) { return; }

      const selectedItems = table.getSelectedItems ? table.getSelectedItems() : [];
      if (!selectedItems || selectedItems.length === 0) {
        MessageToast.show("Please select at least one row to export");
        return;
      }

      const targetLabel = this._getTargetLabel();
      const selectedRows = [];
      for (let i = 0; i < selectedItems.length; i++) {
        const item = selectedItems[i];
        const ctx = item.getBindingContext("inspector");
        if (ctx) {
          const row = ctx.getObject();
          if (row) {
            selectedRows.push(row);
          }
        }
      }

      const csv = buildCsv(selectedRows, targetLabel);
      const ts = new Date().toISOString().replace(/[:.]/g, "-");
      const filename = `methods_selected_${targetLabel.replace(/\s+/g, "_")}_${ts}.csv`;
      downloadCsv(csv, filename);
    },

    // ===== Utilities =====
    onClearResults: function () {
      const data = this._inspectorModel.getData();
      const targetObj = this._getTargetObject();

      data.methods.forEach(m => {
        // Reset only method result fields; attribute rows (if present) remain visible
        if (/^get/.test(m.name)) {
          m.async = "(unknown)";
          m.value = "";
          // Recompute arity (defensive; not strictly required)
          try {
            let arity = 0;
            let curr = targetObj;
            while (curr && curr !== Object.prototype) {
              const desc = Object.getOwnPropertyDescriptor(curr, m.name);
              if (desc && typeof desc.value === "function") {
                arity = desc.value.length || 0;
                break;
              }
              curr = Object.getPrototypeOf(curr);
            }
            m.arity = "args: " + arity;
          } catch (e) {
            m.arity = m.arity || "args: 0";
          }
        } else {
          m.async = m.async || "-";
        }
      });
      this._setMethods(data.methods);

      // Clear table selection
      const table = this.getView().byId("methodsTable");
      if (table && typeof table.removeSelections === "function") {
        table.removeSelections(true);
      }
    },

    onFilterMethods: function (oEvent) {
      const query = (oEvent.getParameter("newValue") || "").toLowerCase();
      if (!this.__allMethods) {
        this.__allMethods = (this._inspectorModel.getData().methods || []).slice(0);
      }
      const filtered = this.__allMethods.filter(m =>
        (m.name && m.name.toLowerCase().includes(query)) ||
        (m.fullPath && m.fullPath.toLowerCase().includes(query))
      );
      this._inspectorModel.setProperty("/methods", filtered);

      // Clear selection after filter change
      const table = this.getView().byId("methodsTable");
      if (table && typeof table.removeSelections === "function") {
        table.removeSelections(true);
      }
    },

    _setMethods: function (rows) {
      this._inspectorModel.setProperty("/methods", rows);
    },

    // ===== Existing hooks kept as-is =====
    onBeforeRenderingPlugin: function () { },

    isSubscribingToNotifications: function() {
      var bNotificationsEnabled = true;
      return bNotificationsEnabled;
    },

    getCustomNotificationEvents: function(sTopic) {
      // none defined
    },

    getNotificationMessageHandler: function(sTopic) {
      return null;
    },

    _handleNotificationMessage: function(oMsg) {
      var sMessage = "Message not found in payload 'message' property";
      if (oMsg && oMsg.parameters && oMsg.parameters.length > 0) {
        for (var i = 0; i < oMsg.parameters.length; i++) {
          switch (oMsg.parameters[i].name){
            case "template":
              break;
            case "template2":
              break;
          }
        }
      }
    },

    onExit: function () {
      PluginViewController.prototype.onExit.apply(this, arguments);
    }
  });
});
